<!-- Insert sidebar script here -->

    <div class="widget search">
        <form action="<?=BASE_URL;?>/search" method="post">
            <input type="text" name="search" class="form-control search_box" value="" placeholder="<?=$this->e($front_search);?>...">
        </form>
    </div>
    <!--/.search-->
    

    <div class="widget archieve">
        <h3><?=$this->e($front_categories);?></h3>
        <div class="row">
            <div class="col-sm-6">
                <ul class="blog_category">
                <?php
                    $categorys_side = $this->category()->getAllCategory(WEB_LANG_ID);
                    foreach($categorys_side as $category_side){
                ?>
                    <li><a href="<?=BASE_URL;?>/category/<?=$category_side['seotitle'];?>"><?=$category_side['title'];?></a></li>
                <?php } ?>
                </ul>
            </div>
        </div>     
    </div>
    <!--/.archieve-->

    <div class="widget popular_post">
        <h3>Popular Post</h3>
        <ul>
            <li>
                <a href="#">
                    <img src="images/post1.png" alt="">
                    <p>Can you get free games for you</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/post2.png" alt="">
                    <p>Can you get free games for you</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/post3.png" alt="">
                    <p>Can you get free games for you</p>
                </a>
            </li>
        </ul>
    </div>
    <!--/.archieve-->
    

    <div class="widget blog_gallery">
        <h3>Our Gallery</h3>
        <ul class="sidebar-gallery clearfix">
            <li>
                <a href="#"><img src="images/sidebar-g-1.png" alt="" /></a>
            </li>
            <li>
                <a href="#"><img src="images/sidebar-g-2.png" alt="" /></a>
            </li>
            <li>
                <a href="#"><img src="images/sidebar-g-3.png" alt="" /></a>
            </li>
            <li>
                <a href="#"><img src="images/sidebar-g-4.png" alt="" /></a>
            </li>
            <li>
                <a href="#"><img src="images/sidebar-g-5.png" alt="" /></a>
            </li>
            <li>
                <a href="#"><img src="images/sidebar-g-6.png" alt="" /></a>
            </li>
        </ul>
    </div>
    <!--/.blog_gallery-->
    
    <div class="widget social_icon">
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-linkedin"></a>
        <a href="#" class="fa fa-pinterest"></a>
        <a href="#" class="fa fa-github"></a>
    </div>
    
