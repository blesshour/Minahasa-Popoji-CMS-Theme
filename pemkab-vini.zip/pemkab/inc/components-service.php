<section id="feature">
        <div class="container">

            <div class="row">
                <div class="features">
                    <div class="col-sm-4 col-xs-12 fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <a href="">
                                <div class="icon">
                                    <i class="fa fa-handshake-o"></i>
                                </div>
                                <h2>Layanan Publik</h2>
                            </a>
                        </div>
                    </div>
                    <!--/.col-sm-4-->
                    <div class="col-sm-4 col-xs-12 fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <a href="">
                                <div class="icon">
                                    <i class="fa fa-commenting"></i>
                                </div>
                                <h2>Suara Anda</h2>
                            </a>
                        </div>
                    </div>
                    <!--/.col-sm-4-->
                    <div class="col-sm-4 col-xs-12 fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <a href="">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <h2>Nomor Telepon Penting</h2>
                            </a>
                        </div>
                    </div>
                    <!--/.col-sm-4-->

                </div>
                <!--/.services-->
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </section>
    <!--/#feature-->