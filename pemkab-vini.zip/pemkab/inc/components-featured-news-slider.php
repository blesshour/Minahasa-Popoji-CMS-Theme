<section id="recent-works">
    <div class="container">
        <div class="center fadeInDown">
            <h2>Info & Berita</h2>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="news2 owl-carousel owl-theme">
                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-1.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>

                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-2.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 7, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    
                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-3.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    
                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-4.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="news2 owl-carousel owl-theme">
                <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-1.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>

                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-2.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 7, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    
                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-3.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    
                    <div class="item post-slide2">
                        <div class="post-img">
                            <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-4.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                            <ul class="post-bar list-inline">
                                <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                <li>
                                    <i class="fa fa-folder"></i>
                                    <a href="#">Mockup</a>
                                    <a href="#">Graphics</a>
                                    <a href="#">Flayers</a>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
 
                <div class="col-md-12">
                    <div id="news-slider2" class="owl-carousel">
                        
                        <div class="post-slide2">
                            <div class="post-img">
                                <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-1.jpg" alt=""></a>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                <ul class="post-bar list-inline">
                                    <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                    <li>
                                        <i class="fa fa-folder"></i>
                                        <a href="#">Mockup</a>
                                        <a href="#">Graphics</a>
                                        <a href="#">Flayers</a>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>

                        <div class="post-slide2">
                            <div class="post-img">
                                <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-2.jpg" alt=""></a>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                <ul class="post-bar list-inline">
                                    <li><i class="fa fa-calendar"></i> June 7, 2016</li>
                                    <li>
                                        <i class="fa fa-folder"></i>
                                        <a href="#">Mockup</a>
                                        <a href="#">Graphics</a>
                                        <a href="#">Flayers</a>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>
                        
                        <div class="post-slide2">
                            <div class="post-img">
                                <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-3.jpg" alt=""></a>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                <ul class="post-bar list-inline">
                                    <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                    <li>
                                        <i class="fa fa-folder"></i>
                                        <a href="#">Mockup</a>
                                        <a href="#">Graphics</a>
                                        <a href="#">Flayers</a>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>
                        
                        <div class="post-slide2">
                            <div class="post-img">
                                <a href="#"><img src="http://bestjquery.com/tutorial/news-slider/demo33/images/img-4.jpg" alt=""></a>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title"><a href="#">Latest News Post</a></h3>
                                <ul class="post-bar list-inline">
                                    <li><i class="fa fa-calendar"></i> June 5, 2016</li>
                                    <li>
                                        <i class="fa fa-folder"></i>
                                        <a href="#">Mockup</a>
                                        <a href="#">Graphics</a>
                                        <a href="#">Flayers</a>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
      

        </div>
        <!-- /.endrow -->
        <div class="clearfix text-center">
            <br>
            <br>
            <a href="#" class="btn btn-primary">Show More</a>
        </div>
    </div>
    <!--/.container-->
</section>
<!--/#recent-works-->