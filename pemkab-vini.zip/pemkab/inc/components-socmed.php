<section id="partner">
        <div class="container">
            <div class="center fadeInDown">
                <h2>Our Partners</h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="partners">
                <ul>
                    <li>
                        <a href="#"><i class="fa fa-facebook fa-5x fadeInDown " data-wow-duration="1000ms " data-wow-delay="900ms"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter-square fa-5x fadeInDown " data-wow-duration="1000ms " data-wow-delay="900ms"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-instagram fa-5x fadeInDown " data-wow-duration="1000ms " data-wow-delay="900ms"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-google-plus fa-5x fadeInDown " data-wow-duration="1000ms " data-wow-delay="900ms"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-youtube fa-5x fadeInDown" data-wow-duration="1000ms " data-wow-delay="900ms"></i></a>
                    </li>
                </ul>
            </div>
        </div>
        <!--/.container-->
    </section>
    <!--/#partner-->
