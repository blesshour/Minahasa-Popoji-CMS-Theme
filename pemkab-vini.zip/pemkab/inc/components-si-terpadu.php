<section id="services" class="service-item">
    <div class="container">
        <div class="center fadeInDown">
            <h2>Our Service</h2>
        </div>

        <div class="row">

        <div class="col-lg-3 col-md-6 col-sm-12 text-center">
            <div class="box fadeInRight">
                <div class="row in-box">
                    <div class="pull-left icon col-3 text-center">
                        <i class="fa fa-commenting"></i>
                    </div>
                    <div class="media-body caption col-9">
                        <h3>Sistem Informasi</h5>
                        <h2 class="media-heading">PANGAN</h4>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 col-sm-12 text-center">
            <div class="box fadeInRight">
                <div class="row in-box">
                    <div class="pull-left icon col-3 text-center">
                        <i class="fa fa-commenting"></i>
                    </div>
                    <div class="media-body caption col-9">
                        <h3>Sistem Informasi</h5>
                        <h2 class="media-heading">PANGAN</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-12 text-center">
            <div class="box fadeInRight">
                <div class="row in-box">
                    <div class="pull-left icon col-3 text-center">
                        <i class="fa fa-commenting"></i>
                    </div>
                    <div class="media-body caption col-9">
                        <h3>Sistem Informasi</h5>
                        <h2 class="media-heading">PANGAN</h4>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 col-sm-12 text-center">
            <div class="box fadeInRight">
                <div class="row in-box">
                    <div class="pull-left icon col-3 text-center">
                        <i class="fa fa-commenting"></i>
                    </div>
                    <div class="media-body caption col-9">
                        <h3>Sistem Informasi</h5>
                        <h2 class="media-heading">PANGAN</h4>
                    </div>
                </div>
            </div>
        </div>


            
        </div>
        <!--/.row-->
    </div>
    <!--/.container-->
</section>
<!--/#services-->