<?=$this->layout('index');?>


<section id="hubungi-kami">
    <div class="container padding">
        <div class="page-header animated fadeInDown">
    <hr>
    <div class="row">
        <div class="col-1"><a class="btn btn-lg btn-link prev"><i class="fas fa-angle-double-left"></i></a></div>
        <div class="col-10 text-center"><h2>JUDUL HALAMAN</h2></div>
        <div class="col-1"><a class="btn btn-lg btn-link next"><i class="fas fa-angle-double-right"></i></a></div>
    </div>
    <hr>
</div>
        <div class="row">
            <div class="col-md-4 col-xs-12">     
                <div class="panel-group padding" id="accordion">
                    <!-- Panel Default / Kontak-->
                    <div class="panel panel-default box wow fadeInRight">
                        <div class="panel-heading">
                            <a data-toggle="collapse" class="active" href="#kontak" aria-expanded="true" aria-controls="kontak">
                            <h5 class="check-title">
                                <span class="fas fa-angle-down"></span> Kontak
                            </h5>
                            </a>
                        </div>
                        <div id="kontak" class="panel-collapse collapse show in" data-parent="#accordion">
                            <div class="panel-body">
                                <address> <i class="fas fa-map-marker-alt"></i>
                                <strong> Alamat </strong>
                                    <br> Tuutu, Tondano Barat
                                    <br> Lingkungan III, Jl.Gn.Mahawu No.206
                                    <br> Sulawesi Utara, KP.95617
                                <address>
                                
                                <br>
                                <p><i class="fas fa-phone"></i>
                                <strong> Nomor Telpon</strong>
                                    <br> 0431 321 123
                                    <br> 08123 4567 xxxx
                                    <br> +62809 8765 43xx
                                </p>

                                <p><i class="fas fa-envelope"></i>
                                <strong> Email</strong>
                                    <br> example@mail.com
                                </p>
                            </div>
                        </div>
                    </div>
                    <!--Panel Nomor Penting-->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse"  aria-expanded="false" aria-controls="nomor-penting" href="#nomor-penting">
                            <h5 class="check-title">
                                <span class="fas fa-angle-down"></span> Nomor Penting
                            </h5></a>
                        </div>
                        <div id="nomor-penting" class="panel-collapse collapse in" data-parent="#accordion">
                            <div class="panel-body">
                                <p><i class="fas fa-fire-extinguisher"></i>
                                <strong> Pemadam Kebakaran</strong>
                                    <br> 0431 321 123
                                    <br> +62809 8765 43xx
                                </p>
                                <p><i class="fas fa-ambulance"></i>
                                <strong> Ambulance</strong>
                                    <br> 0431 321 123
                                    <br> +62809 8765 43xx
                                </p>
                                <p><i class="fas fa-shield-alt"></i>
                                <strong> Polres Minahasa</strong>
                                    <br> 0431 321 123
                                    <br> +62809 8765 43xx
                                </p>
                                <p><i class="fas fa-briefcase-medical"></i>
                                <strong> Rumah Sakit</strong>
                                    <br> 0431 321 123
                                    <br> +62809 8765 43xx
                                </p>
                                <p><i class="fas fa-building"></i>
                                <strong> Disdukcapil</strong>
                                    <br> 0431 321 123
                                    <br> +62809 8765 43xx
                                </p>
                            </div>
                        </div>
                    </div>
                    <!--Panel Sosial Media-->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse"  aria-expanded="false" aria-controls="sosmed" href="#sosmed">
                            <h5 class="check-title">
                                    <span class="fas fa-angle-down"></span> Sosial Media
                            </h5></a>
                        </div>
                        <div id="sosmed" class="panel-collapse collapse in" data-parent="#accordion">
                            <div class="panel-body">
                                <p>
                                    <a href="#"><i class="fab fa-facebook"></i>facebook/username</a>
                                    <br><a href="#"><i class="fab fa-twitter"></i>twitter/username</a>
                                    <br><a href="#"><i class="fab fa-instagram"></i>instagram/username</a>
                                    <br><a href="#"><i class="fab fa-google-plus"></i>googleplus/username</a>
                                    <br><a href="#"><i class="fab fa-youtube"></i>youtube/username</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>  <!--End Panel-->
            </div>
            <div class="col-md-8 col-xs-12">
                <div class="container-fluid padding">
                    <div class="section-suaraAnda-form col-12"> <!--form    Suara Anda-->
                     
                        <section class="" id="form-suara-anda">  
                            <div class="box wow fadeInLeft">
                                <form>
                                    <div class="form-group">
                                        <label for="nama-suaraAnda">Nama</label>
                                        <input type="text" class="form-control" id="nama-suaraAnda" placeholder="contoh: John Doe">
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col">
                                            <label for="email-suaraAnda">E-mail</label>
                                            <input type="text" class="form-control" id="email-suaraAnda" placeholder="contoh: email@saya.com">
                                        </div>
                                        <div class="form-group col">
                                            <label for="kategori-suaraAnda">Kategori</label>
                                            <select id="kategori-suaraAnda" class="form-control">
                                            <option selected>Pertanyaan</option>
                                            <option>...</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="isi-suaraAnda">Suara Anda</label>
                                        <textarea class="form-control" id="isi-suaraAnda" rows="5" placeholder=""></textarea>
                                    </div>
                                    <button class="btn btn-primary">Kirim</button>
                                </form>
                            </div>
                        </section>


                    </div> <!--End form Suara Anda-->
                    <hr>
                    <div class="komentar col-12">    
                        <div class="suaraAnda-display">
                            <div class="media">
                                <img class="align-self-start mr-3 rounded-circle" src="https://via.placeholder.com/50" alt="Generic placeholder image">
                                <div class="media-body">
                                    <h6 class="mt-0">Nama Pengunjung</h6>
                                    <ul class="list-unstyled list-inline text-muted">
                                        <small>
                                        <li class="list-inline-item"><i class="fas fa-date"></i>Tanggal 12/12/2018
                                        <li class="list-inline-item"><i class="fas fa-hour"></i>Pukul 16.00
                                        </small>
                                    </ul>
                                    <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                                </div>
                            </div>
                            <div class="media">
                                <img class="align-self-start mr-3 rounded-circle" src="https://via.placeholder.com/50" alt="Generic placeholder image">
                                <div class="media-body">
                                    <h6 class="mt-0">Nama Pengunjung</h6>
                                    <ul class="list-unstyled list-inline text-muted">
                                        <small>
                                        <li class="list-inline-item"><i class="fas fa-date"></i>Tanggal 12/12/2018
                                        <li class="list-inline-item"><i class="fas fa-hour"></i>Pukul 16.00
                                        </small>
                                    </ul>
                                    <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                                        
                                        <div class="media mt-3">
                                            <img class="align-self-start mr-3 rounded-circle" src="https://via.placeholder.com/50" alt="Generic placeholder image">
                                            <div class="media-body">
                                                <h6 class="mt-0">Nama Pengunjung</h6>
                                                <ul class="list-unstyled list-inline text-muted">
                                                    <small>
                                                    <li class="list-inline-item"><i class="fas fa-date"></i>Tanggal 12/12/2018
                                                    <li class="list-inline-item"><i class="fas fa-hour"></i>Pukul 16.00
                                                    </small>
                                                </ul>
                                                <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="media">
                                <img class="align-self-start mr-3 rounded-circle" src="https://via.placeholder.com/50" alt="Generic placeholder image">
                                <div class="media-body">
                                    <h6 class="mt-0">Nama Pengunjung</h6>
                                    <ul class="list-unstyled list-inline text-muted">
                                        <small>
                                        <li class="list-inline-item"><i class="fas fa-date"></i>Tanggal 12/12/2018
                                        <li class="list-inline-item"><i class="fas fa-hour"></i>Pukul 16.00
                                        </small>
                                    </ul>
                                    <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<section>
