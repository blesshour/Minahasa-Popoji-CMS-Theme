<?=$this->layout('index');?>

<!-- HEADER LAMBANG -->
 <section class="header-selayang" id="header-lambang">
   <div class="jumbotron">
    <div class="container">
     <img src="img/billy.jpg" width="25%">
     <h1 class="display-4">Lambang dan Arti</h1>
    </div>
   </div>
 </section>
 <!-- AKHIR HEADER LAMBANG -->

 <!-- ARTI LAMBANG -->
 <section class="arti-lambang" id="arti-lambang">
  <div class="row">
   <div class="col-lg-4">
    <img src="" alt="Logo" class="img-fluid">
   </div>
   <div class="col-lg-8">
    <ul>
    <li><span>Bentuk Perisai</span> : Suatu simbol untuk kemampuan menghadapi berbagai tantangan</li>
    <li><span>Motto I JAYAT U SANTI</span> : Siap dengan tekad bekerja keras demi pembangunan</li>
    <li><span>Burung manguni</span> : jenis burung yang ada di minahasa, dimana sangat banyak dikagumi orang  karena ia dapat memberi tanda apabila sesuatu akan terjadi, dan mempunyai perasaan dalam serta matanya tajam menatap jauh</li>
    <li><span>Jumlah bulu sayap 17 helai serta ekor 5 helai</span> : Angka proklamasi kemerdekaan Republik Indonesia yang berdasarkan Pancasila</li>
    <li><span>Bagian dada adalah lambang pohon kelapa</span> : Sebagai komoditi minahasa sejak dahulu</li>
    </ul>
   </div>
 </section>
 <!-- ARTI LAMBANG -->