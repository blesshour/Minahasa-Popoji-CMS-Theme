
<?=$this->layout('index');?>
   
   <?php include 'inc/components-featured-news-slider.php'; ?>

